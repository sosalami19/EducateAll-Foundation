# EducateAll-Foundation

#Home Page todo

[x] - Get favicon (not logo) from UI/UX for the website page title

[x] - Get logos from UI/UX and replace my "screenshotted" versions

[ ] - Media queries for tablet, phones, etc

[ ] - Get content to replace the text placeholders

[x] - Get landing page picture from UI/UX and replace mine

[ ] - Get video url for the videos

[x] - Use same exact colours as the UI/UX design

[ ] - Figure out penultimate section of the UI/UX design and include it

[x] - Get social media icons from UI/UX


#Team Page todo

[ ] - (URGENT) Replace mockTeam's value (in scripts/team.js) with actual team data from our Google spreadsheet

[ ] - Get picture used for team page design from UI/UX team

[ ] - Implement dropdown for team link in the header's navbar